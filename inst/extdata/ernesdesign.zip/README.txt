MultiLand 
 
This directory was created by R package multilandr. 
 
No modifications of folders or files should be made by hand. 
 
This folder may be loaded into an R session as a 'MultiLand' object with function load_mland().